#ifndef HX1838IRDECODER_H
#define HX1838IRDECODER_H

#include <Arduino.h>

#define BUFFER_SIZE 100  // Maximum number of pulse entries

class IRDecoder {
public:
    IRDecoder(uint8_t pin);
    void begin();
    bool available();
    uint32_t getDecodedData();
    
private:
    static void IRAM_ATTR handleIRSignal();
    static uint32_t reverseBits32(uint32_t num);
    void processSignal();

    static volatile unsigned long pulseTimes[BUFFER_SIZE];
    static volatile int pulseIndex;
    static volatile unsigned long lastTime;
    
    uint8_t irPin;
    uint32_t lastDecodedData;
};

#endif
